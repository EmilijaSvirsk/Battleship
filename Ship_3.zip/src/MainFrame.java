import Player.Player;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MainFrame implements ActionListener{
	private JFrame frame;
	private JButton buttonM[][];
	private JPanel panelM;
	private JButton buttonE[][];
	private JPanel panelE;
	private JPanel lowPanel;
	private JPanel highPanel;
	private JTextArea text;
	private Player play1;
	private Player play2;
	private String infoMess = "Click any button below to start the game.";
	
	public MainFrame(Player play1, Player play2)
	{
		this.play1 = play1;
		this.play2 = play2;
		frame = new JFrame("BattleShip");
		buttonM = new JButton[10][10];
		panelM = new JPanel();
		buttonE = new JButton[10][10];
		panelE = new JPanel();
		lowPanel = new JPanel();
		highPanel = new JPanel();
		text = new JTextArea(infoMess,10,25); 
		
		createPanelM();
		createPanelE();
		createHighPanel();
		createLowPanel();
		createFrame();
	}
	
	public void start()
	{
		frame.setVisible(true);
	}
	
	private void createPanelM()
	{
		panelM.setLayout(new GridLayout(10, 10));
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonM[j][i] = new JButton();
				buttonM[j][i].setText(play1.checkBlockM(j,i));
				buttonM[j][i].setBackground(Color.WHITE);
				buttonM[j][i].setEnabled(false);
				panelM.add(buttonM[j][i]);
			}
		}
	}
	
	private void createPanelE()
	{
		panelE.setLayout(new GridLayout(10, 10));
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonE[j][i] = new JButton();
				buttonE[j][i].setText(".");
				buttonE[j][i].setBackground(Color.WHITE);
				panelE.add(buttonE[j][i]);
				buttonE[j][i].setActionCommand(String.valueOf(j)+String.valueOf(i));
				buttonE[j][i].addActionListener(this);
			}
		}
	}
	
	private void createHighPanel()
	{
		highPanel.setSize(150,500);
		highPanel.setLayout(new FlowLayout());
		highPanel.add(panelM);
		//text.setSize(100, 100);
		text.setEditable(false);
		highPanel.add(text);
	}
	
	private void createLowPanel()
	{
		//lowPanel.setSize(100,500);
		lowPanel.add(panelE);
	}
	
	private void createFrame()
	{
		frame.setSize(900,700);
		frame.setLayout(new GridLayout(2, 1));
		frame.add(highPanel);
		frame.add(lowPanel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent e) {
		String command = (e.getActionCommand());
		text.setText(command);
		int x = Integer.parseInt(String.valueOf(command.substring(0,1)));
		int y = Integer.parseInt(String.valueOf(command.substring(1,2)));
		
		if(play1.takeAim(play2, x, y))
			text.setText(play1.getName() + " got a successful shot!\n");
		else
			text.setText(play1.getName() + " missed the shot.\n");
		changeButtonE(x, y);
		
		if(play2.takeAim(play1, 0, 0))
			text.append(play2.getName() + " got a successful shot!");
		else
			text.append(play2.getName() + " missed the shot.");
		changeButtonM();
	}
	
	private void changeButtonE(int x, int y)
	{
		buttonE[x][y].setText(play1.checkBlockE(x,y));
		//buttonM[x][y].setBackground(Color.WHITE);
		buttonE[x][y].setEnabled(false);
	}
	private void changeButtonM()
	{
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonM[j][i].setText(play2.checkBlockE(j,i));
			}
		}
	}
}


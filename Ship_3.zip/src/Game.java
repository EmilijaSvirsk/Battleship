import Player.Player;
import Player.Computer;
import Player.Person;
public class Game{
	
	public static void main(String[] args) {
		Player person = new Person("Protagonist");
		Player comp = new Computer("Antagonist");
		
		MainFrame mainFrame = new MainFrame(person, comp);
		mainFrame.start();
	}

}

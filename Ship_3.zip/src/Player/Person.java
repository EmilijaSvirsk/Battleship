package Player;
import Structure.Ship;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Person extends Player {
	
	public Person(String name)
	{
		super(name);
	}
	
	protected void createGridMine()
	{
		String fl = "bin/ships.txt";
		gridM.create();
		try 
		{
			FileReader fr = new FileReader(fl);
			BufferedReader read = new BufferedReader(fr);
			String line;
			String coord[] = new String[4];
			for(int i = 0; i < 7; i++)
			{
				line = read.readLine();
				coord = line.split(";");
				ship[i] = new Ship(Integer.parseInt(coord[0]),
								   Integer.parseInt(coord[1]),
								   Integer.parseInt(coord[2]), 
								   coord[3]);
				gridM.place(ship[i]);
			}
			fr.close();
		} catch (IOException e) {
            e.printStackTrace();
		}
	}
	
	public boolean takeAim(Player comp, int x, int y)
	{
		boolean shot = comp.shot(x, y);
		gridE.mark(x, y, shot);
		return shot;
	}
}

package Player;
import Structure.Gridline;
import Structure.Ship;

public abstract class Player {
	protected Gridline gridM;
	protected Gridline gridE;
	protected Ship ship[];
	protected String name;
	
	Player(String name)
	{
		this.name = name;
		ship = new Ship[7];
		gridM = new Gridline(10,10);
		createGridMine();
		gridE = new Gridline(10,10);
		createGridEnem();
	}
	
	public abstract boolean takeAim(Player pers, int x, int y);
	
	protected abstract void createGridMine();
	
	public void createGridEnem()
	{
		gridE.create();
	}
	
	public Gridline gridlineMine()
	{
		return gridM;
	}
	
	public void printMine()
	{
		gridM.print();
	}
	
	public void printEnem()
	{
		gridE.print();
	}
	
	public boolean shot(int x, int y)
	{
		if(gridM.shot(x, y) == true)
			return true;
		else
			return false;
	}
	
	public boolean checkRemainingShips()
	{
		int ships = 7;
		for(int i = 0; i < 7; i++)
		{
			if(ship[i].destroyed == true)
				--ships;
		}
		System.out.println(ships + " left out of 7.");
		if(ships == 0)
			return true;
		else
			return false;
	}
	
	public String checkBlockM(int x, int y)
	{
		return gridM.checkBlock(x, y);
	}
	public String checkBlockE(int x, int y)
	{
		return gridE.checkBlock(x, y);
	}
	
	public String getName()
	{
		return this.name;
	}
}

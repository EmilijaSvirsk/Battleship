import Player.Player;
import Structure.ShipCount;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import FileExceptions.BadFileException;

public class MainFrame implements ActionListener{
	private JFrame frame;
	private JButton buttonM[][];
	private JPanel panelM;
	private JButton buttonE[][];
	private JPanel panelE;
	private JPanel lowPanel;
	private JPanel highPanel;
	private JTextArea text;
	private Player play1;
	private ShipCount count1;
	private Player play2;
	private ShipCount count2;
	private String infoMess = "Click any button below to start the game.";
	private JTable table;
	private String[] columnNames;
	private JScrollPane scrollPane;
	private boolean endGame;
	
	public MainFrame(Player play1, Player play2)
	{
		endGame = false;
		this.play1 = play1;
		this.play2 = play2;
		try
		{
			play1.createGridMine();
			play2.createGridMine();
		}
		catch(BadFileException e)
		{
			e.printMessage();
			endGame = true;
		}
		if(endGame == false)
			initiateComponents();
	}
	private void initiateComponents()
	{
		count1 = new ShipCount(play1);
		count2 = new ShipCount(play2);
		frame = new JFrame("BattleShip");
		buttonM = new JButton[10][10];
		panelM = new JPanel();
		buttonE = new JButton[10][10];
		panelE = new JPanel();
		lowPanel = new JPanel();
		highPanel = new JPanel();
		text = new JTextArea(infoMess,10,25);
		columnNames = new String[] {
				"Length", play1.getName(), play2.getName()
			};
		table = new JTable(tableContent(), columnNames);
		scrollPane = new JScrollPane(table, 
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		createPanelM();
		createPanelE();
		createHighPanel();
		createLowPanel();
		createFrame();
	}
	
	private Object[][] tableContent()
	{
		Object[][] data = new Object[][] {
			{5 , count1.getDestroyed(0), count2.getDestroyed(0)},
			{4, count1.getDestroyed(1), count2.getDestroyed(1)},
			{3, count1.getDestroyed(2), count2.getDestroyed(2)},
			{2, count1.getDestroyed(3), count2.getDestroyed(3)},
			{2, count1.getDestroyed(4), count2.getDestroyed(4)},
			{1, count1.getDestroyed(5), count2.getDestroyed(5)},
			{1, count1.getDestroyed(6), count2.getDestroyed(6)}
		};
		return data;
	}
	
	public void start()
	{
		if(endGame == false)
			frame.setVisible(true);
	}
	
	private void createPanelM()
	{
		panelM.setLayout(new GridLayout(10, 10));
		panelM.setPreferredSize(new Dimension(450, 300));
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonM[j][i] = new JButton();
				buttonM[j][i].setText(play1.checkBlockM(j,i));
				buttonM[j][i].setBackground(Color.WHITE);
				buttonM[j][i].setEnabled(false);
				panelM.add(buttonM[j][i]);
			}
		}
	}
	
	private void createPanelE()
	{
		panelE.setLayout(new GridLayout(10, 10));
		panelE.setPreferredSize(new Dimension(450, 300));
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonE[j][i] = new JButton();
				buttonE[j][i].setText(".");
				buttonE[j][i].setBackground(Color.WHITE);
				panelE.add(buttonE[j][i]);
				buttonE[j][i].setActionCommand(String.valueOf(j)+String.valueOf(i));
				buttonE[j][i].addActionListener(this);
			}
		}
	}
	
	private void createHighPanel()
	{
		highPanel.setSize(150,500);
		highPanel.setLayout(new FlowLayout());
		highPanel.add(panelM);
		//text.setSize(100, 100);
		scrollPane.setPreferredSize(new Dimension(300, 136));
		highPanel.add(scrollPane);
	}
	
	private void createLowPanel()
	{
		//lowPanel.setSize(100,500);
		lowPanel.add(panelE);
		text.setEditable(false);
		lowPanel.add(text);
		//scrollPane.setPreferredSize(new Dimension(40, 0));
		//scrollPane.setSize(1000,1000);
	}
	
	private void createFrame()
	{
		frame.setSize(900,700);
		frame.setLayout(new GridLayout(2, 1));
		frame.add(highPanel);
		frame.add(lowPanel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent e) {
		if(endGame == true)
			return;
		String command = (e.getActionCommand());
		text.setText(command);
		int x = Integer.parseInt(String.valueOf(command.substring(0,1)));
		int y = Integer.parseInt(String.valueOf(command.substring(1,2)));
		
		if(play1.takeAim(play2, x, y))
			text.setText(play1.getName() + " got a successful shot!\n");
		else
			text.setText(play1.getName() + " missed the shot.\n");
		int updateCount2 = count2.destroyedUpdate();
		if(updateCount2 != -1)
			text.append(play2.getName() + "'s " + updateCount2 + " length ship was destroyed!\n");
		changeButtonE(x, y);
		
		if(play2.takeAim(play1, 0, 0))
			text.append(play2.getName() + " got a successful shot!\n");
		else
			text.append(play2.getName() + " missed the shot.\n");
		int updateCount1 = count1.destroyedUpdate();
		if(updateCount1 != -1)
			text.append(play1.getName() + "'s " + updateCount1 + " length ship was destroyed!\n");
		changeButtonM();
		
		updateTable();
		checkEnd();
	}
	
	private void changeButtonE(int x, int y)
	{
		buttonE[x][y].setText(play1.checkBlockE(x,y));
		//buttonM[x][y].setBackground(Color.WHITE);
		buttonE[x][y].setEnabled(false);
	}
	private void changeButtonM()
	{
		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j < 10; j++)
			{
				buttonM[j][i].setText(play2.checkBlockE(j,i));
			}
		}
	}
	
	private void updateTable()
	{
		table.setModel(new DefaultTableModel(tableContent(), columnNames));
	}
	
	private void checkEnd()
	{
		if(count1.allDestroyed() && count2.allDestroyed())
		{
			text.append("Game ends in draw!\n");
			endGame = true;
		}
		else if(count1.allDestroyed())
		{
			text.append(play2.getName() + " wins the game!\n");
			endGame = true;
		}
		else if(count2.allDestroyed())
		{
			text.append(play1.getName() + " wins the game!\n");
			endGame = true;
		}
	}
}


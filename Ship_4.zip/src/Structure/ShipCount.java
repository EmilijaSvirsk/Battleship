package Structure;
import Player.Player;

public class ShipCount {
	Ship ships[];
	boolean destroyed[];
	
	public ShipCount(Player play)
	{
		this.ships = play.getShips();
		destroyed = new boolean[7];
		for(int i = 0; i < 7; i++)
			destroyed[i] = false;
	}
	
	public int destroyedUpdate()
	//returns the newly destroyed ships parameters, if nothing destroyed then -1
	{
		for(int i = 0; i < 7; i++)
		{
			if(ships[i].destroyed != destroyed[i])
			{
				destroyed[i] = true;
				return ships[i].n;
			}
		}
		return -1;
	}
	
	public boolean allDestroyed()
	{
		int count = 0;
		for(boolean i : destroyed)
			if(i == true) count++;
		
		if(count == 7)
			return true;
		else
			return false;
	}
	
	public boolean getDestroyed(int i)
	{
		return destroyed[i];
	}
	
}

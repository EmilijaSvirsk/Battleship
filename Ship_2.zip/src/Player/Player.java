package Player;
import Structure.Gridline;
import Structure.Ship;

public abstract class Player {
	protected Gridline gridM = new Gridline(10,10);
	protected Gridline gridE = new Gridline(10,10);
	protected Ship ship[] = new Ship[7];
	
	Player()
	{
		createGridMine();
		createGridEnem();
	}
	
	public abstract void takeAim(Player pers);
	
	protected abstract void createGridMine();
	
	public void createGridEnem()
	{
		gridE.create();
	}
	
	public void printMine()
	{
		gridM.print();
	}
	
	public void printEnem()
	{
		gridE.print();
	}
	
	public boolean shot(int x, int y)
	{
		if(gridM.shot(x, y) == true)
			return true;
		else
			return false;
	}
	
	public boolean checkRemainingShips()
	{
		int ships = 7;
		for(int i = 0; i < 7; i++)
		{
			if(ship[i].destroyed == true)
				--ships;
		}
		System.out.println(ships + " left out of 7.");
		if(ships == 0)
			return true;
		else
			return false;
	}
}

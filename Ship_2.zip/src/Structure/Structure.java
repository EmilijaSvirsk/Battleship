package Structure;
interface Structure {
	void place(Ship ship);
}

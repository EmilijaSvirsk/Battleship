import Player.Player;
import Player.Computer;
import Player.Person;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Game{
	
	public static void main(String[] args) {
		/*Person person = new Person();
		person.printMine();
		
		Person comp = new Computer();
		comp.printMine();
		
		while(person.checkRemainingShips() == false &&
			  comp.checkRemainingShips() == false )
		{
			person.printEnem();
			person.takeAim(comp);
			comp.printEnem();
			comp.takeAim(person);
		}
		if(person.checkRemainingShips() == true)
			System.out.println("Computer wins!");
		else
			System.out.println("You win!");*/
		
		
		/*Player litvinas = new Computer();
		litvinas.printMine();
		
		Player radavicius = new Computer();
		radavicius.printMine();
		
		while(litvinas.checkRemainingShips() == false &&
			  radavicius.checkRemainingShips() == false )
		{
			litvinas.printEnem();
			litvinas.takeAim(radavicius);
			radavicius.printEnem();
			radavicius.takeAim(litvinas);
		}
		if(litvinas.checkRemainingShips() == true &&
		   radavicius.checkRemainingShips() == true	)
		{
			System.out.println("Draw!");
		}
		else if(litvinas.checkRemainingShips() == true)
			System.out.println("Radavicius wins!");
		else
			System.out.println("Litvinas wins!");*/
		JFrame frame = new JFrame("Ship");
	    frame.setSize(400,400);
	    frame.setLayout(new GridLayout(10, 10));//!!!
	    //panel for one grid, within grid 100 buttons
	    //change marking when pressed
	    frame.setVisible(true);  
	    JButton but = new JButton("OK");
	    but.setActionCommand("OK");
	    frame.add(but);
	    //JPanel panel = new JPanel();
	    //panel.setLayout(new FlowLayout());
	}

}

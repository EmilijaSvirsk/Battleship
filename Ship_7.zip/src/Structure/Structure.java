package Structure;
import Ship.Ship;

interface Structure {
	
	void place(Ship ship);
	
	void create();
}

import Player.Player;
import Player.Computer;
import Player.Person;
public class Game{
	
	public static void main(String[] args) {		
		Player person = new Person("Protagonist");
		Player comp = new Computer("Antagonist");
		MainFrame mainFrame = MainFrame.getMainFrame();
		if(mainFrame.startMain(person, comp))
		{
			Splash splash1 = mainFrame.startSplash1();
			Splash splash2 = mainFrame.startSplash2();
			splash1.start();
			splash2.start();
		}
	}

}

package Player;
import Structure.Ship;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class Person extends Player{
	
	public Person()
	{
		CreateGridMine("bin/ships.txt");
		CreateGridEnem();
	}
	
	public void CreateGridMine(String fl)
	{
		gridm.Create();
		try 
		{
			FileReader fr = new FileReader(fl);
			BufferedReader read = new BufferedReader(fr);
			String line;
			String coord[] = new String[4];
			for(int i = 0; i < 7; i++)
			{
				line = read.readLine();
				coord = line.split(";");
				ship[i] = new Ship(Integer.parseInt(coord[0]),
								   Integer.parseInt(coord[1]),
								   Integer.parseInt(coord[2]), 
								   coord[3]);
				gridm.Place(ship[i]);
			}
			fr.close();
		} catch (IOException e) {
            e.printStackTrace(); //df?
		}
	}
	
	public void TakeAim(Person comp)
	{
		boolean shot = false;
		Scanner input = new Scanner(System.in);
		while(shot == false)
		{
			int x1, y1;
			System.out.println("Input shot's x:");
			x1 = input.nextInt();
			if(x1 >= 0 && x1 < 10)
			{
				System.out.println("Input shot's y:");
				y1 = input.nextInt();
				if(y1 >= 0 && y1 < 10)
				{
					if(gride.CheckShot(x1, y1) == true)
						{
							gride.Mark(x1, y1, comp.Shot(x1, y1));
							shot = true;
						}
					else
						System.out.println("You have already shot there.");
				}
				else
					System.out.println("Incorrect y, try again.");	
			}
			else
				System.out.println("Incorrect x, try again.");
		}
		//input.close();
	}
}

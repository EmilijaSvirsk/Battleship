package Player;
import Structure.Gridline;
import Structure.Ship;

public abstract class Player {
	protected Gridline gridm = new Gridline(10,10);
	protected Gridline gride = new Gridline(10,10);
	protected Ship ship[] = new Ship[7];
	
	public void CreateGridEnem()
	{
		gride.Create();
	}
	
	public void PrintMine()
	{
		gridm.Print();
	}
	
	public void PrintEnem()
	{
		gride.Print();
	}
	
	public boolean Shot(int x, int y)
	{
		if(gridm.Shot(x, y) == true)
			return true;
		else
			return false;
	}
	
	public boolean CheckRemainingShips()
	{
		int ships = 7;
		for(int i = 0; i < 7; i++)
		{
			if(ship[i].destroyed == true)
				--ships;
		}
		System.out.println(ships + " left out of 7.");
		if(ships == 0)
			return true;
		else
			return false;
	}
}

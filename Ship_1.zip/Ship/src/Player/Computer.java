package Player;
import Structure.Ship;
import java.util.Random;

public class Computer extends Person {

	public Computer()
	{
		CreateGridMine();
		CreateGridEnem();
	}
	
	public void CreateGridMine()
	{
		gridm.Create();
		Random random = new Random();
		int shipN[] = {5, 4, 3, 2, 2, 1, 1};
		int n = 0;
		for(int i:shipN)
		{
			boolean next = false;
			int x1 = 0;
			int y1 = 0;
			String dir[] = {"r", "d"};
			int dirN = 0;
			
			while(next == false)
			{
				x1 = random.nextInt(10);
				y1 = random.nextInt(10);
				dirN = random.nextInt(2);
				next = gridm.CheckShip(i, x1, y1, dir[dirN]);
			}
			ship[n] = new Ship(i, x1, y1, dir[dirN]);
			gridm.Place(ship[n]);
			n++;
		}
	}
	public void TakeAim(Person pers)
	{
		Random random = new Random();
		boolean next = false;
		int x1 = 0;
		int y1 = 0;
		while(next == false)
		{
			x1 = random.nextInt(10);
			y1 = random.nextInt(10);
			if(gride.CheckShot(x1, y1) == true)
			{
				gride.Mark(x1, y1, pers.Shot(x1, y1));
				next = true;
			}
		}
	}
}

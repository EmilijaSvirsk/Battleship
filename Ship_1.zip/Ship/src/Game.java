import Player.Person;
import Player.Computer;
public class Game{
	
	public static void main(String[] args) {
		Person person = new Person();
		person.PrintMine();
		
		Person comp = new Computer();
		comp.PrintMine();
		
		while(person.CheckRemainingShips() == false &&
			  comp.CheckRemainingShips() == false )
		{
			person.PrintEnem();
			person.TakeAim(comp);
			comp.PrintEnem();
			comp.TakeAim(person);
		}
		if(person.CheckRemainingShips() == true)
			System.out.println("Computer wins!");
		else
			System.out.println("You win!");
		
		
		/*Person litvinas = new Computer();
		litvinas.PrintMine();
		
		Person radavicius = new Computer();
		radavicius.PrintMine();
		
		while(litvinas.CheckRemainingShips() == false &&
			  radavicius.CheckRemainingShips() == false )
		{
			litvinas.PrintEnem();
			litvinas.TakeAim(radavicius);
			radavicius.PrintEnem();
			radavicius.TakeAim(litvinas);
		}
		if(litvinas.CheckRemainingShips() == true)
			System.out.println("Radavicius wins!");
		else
			System.out.println("Litvinas wins!");*/
	}

}

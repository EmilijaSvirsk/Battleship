package Structure;
interface Structure {
	public void Place(Ship ship);
}

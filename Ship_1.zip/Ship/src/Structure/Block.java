package Structure;
public class Block implements Structure{
	public int x;
	public int y;
	public char show; 
	public boolean placed;
	public boolean shot;
	public Ship ship;
	
	public Block(int x, int y)
	{
		this.x = x;
		this.y = y;
		show = '.';
		placed = false;
		shot = false;
	}
	
	public void Shot(boolean hit)
	{
		shot = true;
		if(hit == true)
			show = 'X';
		else
			show = '+';
		
		if(placed == true)
			ship.Shot();
	}
	
	public void Place(Ship ship1)
	{
		ship = ship1;
		placed = true;
		show = 'O';
	}
}

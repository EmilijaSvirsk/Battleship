package Structure;
public class Gridline implements Structure{
	private int x;
	private int y;
	private Block grid[][];
	
	public Gridline(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	public void Create()
	{
		grid = new Block[x][y];
		for(int i = 0; i < x; i++)
		{
			for(int j = 0; j < y; j++)
			{
				grid[i][j] = new Block(i,j);
			}
		}
	}
	
	public void Print()
	{
		for(int i = 0; i < y; i++)
		{
			for(int j = 0; j < x; j++)
			{
				System.out.printf("%c ", grid[j][i].show);
			}
			System.out.println();
		}
	}
	
	public boolean CheckShot(int x1, int y1) //check if a shot can be done in enemies grid
	{
		if(grid[x1][y1].shot == false)
			return true;
		else
			return false;
	}
	
	public boolean CheckShip(int n, int x1, int y1, String dir)
	{	
		if(n == 1)
		{
			return !grid[x1][y1].placed;
		}
		
		if(dir.equals("r") && x1+n < 10) //right
		{
			for(int i = 0; i < n; i++)
			{
				if(grid[x1+i][y1].placed == true)
					return false;
			}
			return true;
		}
		if(dir.equals("d") && y1+n < 10) //down
		{
			for(int i = 0; i < n; i++)
			{
				if(grid[x1][y1+i].placed == true)
					return false;
			}
			return true;
		}
		
		return false;
	}
	
	public void Place(Ship ship) //place a ship on the gridline in creation
	{
		int x1 = ship.x;
		int y1 = ship.y;
		int n = ship.n;
		String dir = ship.dir; 
		if(n == 1)
		{
			grid[x1][y1].Place(ship);
			ship.Place(0, grid[x1][y1]);
			return;
		}
		
		if(dir.equals("r")) //right
		{
			for(int i = 0; i < n; i++)
			{
				grid[x1+i][y1].Place(ship);
				ship.Place(i, grid[x1+i][y1]);
			}
			return;
		}
		if(dir.equals("d")) //down
		{
			for(int i = 0; i < n; i++)
			{
				grid[x1][y1+i].Place(ship);
				ship.Place(i, grid[x1][y1+i]);
			}
			return;
		}
	}
	
	public boolean Shot(int x1, int y1) //return if the shot on you was successful and mark that place
	//also write a message!
	{
		grid[x1][y1].Shot(grid[x1][y1].placed);
		if(grid[x1][y1].placed)
			System.out.println("Shot successful!");
		else
			System.out.println("Shot missed.");
		return grid[x1][y1].placed;
	}
	
	public void Mark(int x1, int y1, boolean hit) 
	//mark on the enemies grid the shot according to outcome
	{
		grid[x1][y1].Shot(hit);
	}
}

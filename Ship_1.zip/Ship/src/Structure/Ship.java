package Structure;
public class Ship {
	private Block place[];
	public int n;
	public int x;
	public int y;
	public String dir;
	public boolean destroyed;
	private int lives;
	
	public Ship(int n, int x, int y, String dir)
	{
		this.x = x;
		this.y = y;
		this.n = n;
		this.dir = dir;
		destroyed = false;
		place = new Block[n];
		lives = n;
	}
	
	public void Place(int i, Block block)
	{
		place[i] = block;
	}
	public void Shot()
	{
		--lives;
		if(lives == 0)
			destroyed = true;
	}
}
